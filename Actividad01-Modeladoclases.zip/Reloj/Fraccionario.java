public class Fraccionario {

	private int numerador;

	private int denominador;

}
