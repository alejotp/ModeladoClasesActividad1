public class reloj {

	private int horas;

	private int minutos;

	private int segundos;

}
