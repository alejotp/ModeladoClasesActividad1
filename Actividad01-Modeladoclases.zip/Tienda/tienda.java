public class tienda {

	private String direccion;

	private int telefono;

	private String nombre;

}
