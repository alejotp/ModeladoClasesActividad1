public class producto {

	private int codigo;

	private String nombre;

	private String tipo;

	private date fecja;

	private String nombreFabricante;

	private int cantidad;

	private double precioUnitario;

}
