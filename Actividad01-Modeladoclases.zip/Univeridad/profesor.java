public class profesor {

	private String profesion;

	private String nacionalidad;

	private double sueldo;

}
