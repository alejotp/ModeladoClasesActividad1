public class curso {

	private int codigo;

	private String nombreCurso;

	private int attribute30;

	private int numeroCreditos;

	private String carreraPertenece;

	private String salon;

	private String profesor;

	private int numeroEstudiantes;

}
