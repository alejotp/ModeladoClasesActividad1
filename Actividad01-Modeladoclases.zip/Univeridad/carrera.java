public class carrera {

	private String nombre;

	private int numeroCreditos;

	private int numeroSemestres;

	private String nivelCarrera;

	private String facultad;

}
