public class universidad {

	private String nombre;

	private String nombreRector;

	private String ciudad;

}
