public class facultad {

	private String nombre;

	private String cursos;

}
