public class Persona {

	private int cedula;

	private String nombre;

	private date fechaNacimiento;

	private String LugarNacimiento;

}
