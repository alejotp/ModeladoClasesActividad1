public class estudiante  {

	private String semestre;

	private String carrera;

	private date fechaIngreso;

}
