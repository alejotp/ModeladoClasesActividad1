public class proyectil {

	private int peso;

	private int diametro;

	public boolean velocidadDisparo() {
		return false;
	}

	public double anguloDisparo() {
		return 0;
	}

}
