public class fecha {

	private int año;

	private fecha mes;

	private int segundos;

}
